function [R_pe]=R_asymp(m,w,beta,mu,eta,nbar)

V_A=mu-1;
V_N=2*nbar+1;
V_B=eta*(mu-1)+2*nbar+1;

eta_wc=eta-2*w*eta*sqrt((2+(V_N+1)/(eta*V_A))/(2*m));
nbar_wc=nbar+w*(V_N+1)/sqrt(4*m);

I_AB=log2(1+eta_wc*V_A/(1+V_N));

nu_p=(1-eta_wc)*mu;
nu_n=1+2*nbar_wc/(1-eta_wc);
nu_cond=mu-eta_wc*(mu^2-1)/(V_B+1);
chi_EB=gx(nu_p)+gx(nu_n)-gx(nu_cond);

R_pe=beta*I_AB-chi_EB;
end
