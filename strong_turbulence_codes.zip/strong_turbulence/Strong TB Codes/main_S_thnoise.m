clear all
close all
clc

W0=5e-2;
aR=5e-2;
lambda=800e-9;
k=2*pi/lambda;
zR=pi*W0^2/lambda;

Cn2=2.06e-14;    %  NIGHT 1.28e-14  DAY 2.06e-14
nbar_B=4.75e-7;  %  NIGHT 4.8e-12   DAY 4.8e-7

eta_eff=1;
nbar_ex=0.0;
nbar=eta_eff*nbar_B+nbar_ex;

L0=1;
C0=2*pi;
kappa0=C0/L0;
R0=inf; 

l0=0.001;
z_i=(Cn2*k^2*l0^(5/3))^(-1);
z=linspace(1e3,z_i,1e3);

for j=1:length(z)
    
h=30;
alpha0=5e-6;    
eta_atm=exp(-alpha0*exp(-h/6600)*z(j));

Wz2=W0^2*((1-z(j)/R0).^2+(z(j)/zR).^2);
Sig2_Ry=1.23*Cn2*k^(7/6)*(z(j))^(11/6);

% Effective radius of curvature : Begin
Qm=35.05*z(j)/(k*l0^2);
%q=0.74*Sig2_Ry*Qm^(1/6);     % z > z_i
q=1.22*Sig2_Ry^(6/5);          % z < z_i
Theta0=1-z(j)/R0;
Lambda0=2*z(j)/(k*W0^2);
Theta=Theta0/(Theta0^2+Lambda0^2);
Lambda=Lambda0/(Theta0^2+Lambda0^2);
%Rlt=-z(j)*(1+4*q*Lambda/3)/(1-Theta+2*q*Lambda);
% Effective radius of curvature : End

% Effective long-term spot radius : Begin
Wlt2=Wz2*(1+4*q*Lambda/3);
% Effective long-term spot radius : End

% Effective long-term transmisivity : Begin
eta_lt=1-exp(-2*aR^2/Wlt2);
eta=eta_lt*eta_eff*eta_atm;
% Effective long-term transmisivity : End

K_UP(j)=-log2(1-eta);

h=@(x) (x+1)*log2(x+1)-x*log2(x);

%K_TUP(j)=-log2(1-eta)+log2(1-nbar);
K_TUP2(j)=-log2(1-eta)-h(nbar/(1-nbar))-(nbar/(1-eta))*log2(eta);
K_low(j)=-log2(1-eta)-h(nbar/(1-eta));

z_km(j)=z(j)/1000;

end


figure(1)
semilogy(z_km,K_UP,z_km,K_TUP2,z_km,K_low,'LineWidth',2)%,'Color',[1 0.5 0])
set(gca,'FontSize',14)
xlabel('Distance (km)','FontSize',14)
ylabel('Rates (bits/use)','FontSize',14)
xlim([-5 205])
ylim([1e-8 10])