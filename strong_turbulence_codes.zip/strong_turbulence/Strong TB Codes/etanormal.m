clear all
close all
clc

W0=5e-2;       
aR=5e-2;       
lambda=800e-9;
k=2*pi/lambda;
zR=pi*W0^2/lambda;

Cn2=2.06e-14;      %  NIGHT 1.28e-14
  
h=30;
R0=inf; 
l0=0.001;
z_i=(Cn2*k^2*l0^(5/3))^(-1);

aRinf=50;
%z=5e3:5e3:90e3;
z=linspace(.9e3,15e3,1e3);

for j=1:length(z)
    
Wz2=W0^2*((1-z(j)/R0).^2+(z(j)/zR).^2);
Sig2_Ry=1.23*Cn2*k^(7/6)*(z(j))^(11/6); 

Qm=35.05*z(j)/(k*l0^2);
%q=0.74*Sig2_Ry*Qm^(1/6);        % z > z_i
q=1.22*Sig2_Ry^(6/5);            % z < z_i
Theta0=1-z(j)/R0;
Lambda0=2*z(j)/(k*W0^2);
Theta=Theta0/(Theta0^2+Lambda0^2);
Lambda=Lambda0/(Theta0^2+Lambda0^2);  
Wlt2=Wz2*(1+4*q*Lambda/3);

eta_ltLN(j)=1-exp(-2*aR^2/Wlt2);   % LOG-NORMAL MODEL

z_km(j)=z(j)/1000;
end

figure(1)
semilogy(z_km,eta_ltLN,'LineWidth',1.5,'Color',[0.69 0.40 0.00])
set(gca,'FontSize',14)
xlabel('Distance (km)','FontSize',14)
ylabel('\eta_{lt}','FontSize',14)

