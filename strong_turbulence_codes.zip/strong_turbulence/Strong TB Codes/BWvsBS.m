clear all
close all
clc

W0=5e-2;
lambda=800e-9;
k=2*pi/lambda;
Cn2=1.28e-14; % NIGHT
zR=pi*W0^2/lambda;

L0=1;
C0=2*pi;
kappa0=C0/L0;


l0=0.001;
z_i=(Cn2*k^2*l0^(5/3))^(-1);

z=linspace(1e3,200e3,1e3); 

for j=1:length(z)
    
Sig2Ry=1.23*Cn2*k^(7/6)*(z(j))^(11/6);
SigR2(j)=Sig2Ry;
R0=inf; 
Wz2=W0^2*((1-z(j)/R0).^2+(z(j)/zR).^2);

Theta0=1-z(j)/R0;
Lambda0=2*z(j)/(k*W0^2);

Theta0bar=1-Theta0;
f=@(x) (Theta0+Theta0bar*x).^2+1.63*(Sig2Ry).^(12/10)*Lambda0.*(1-x).^(16/5);
F_int=@(x) x.^2.* ( 1./(f(x)).^(1/6) - (kappa0*W0)^(1/3)./(1+kappa0^2*W0^2*f(x)).^(1/6) );
A_int=integral(F_int,0,1);
SigTB2(j)=7.25*Cn2*(z(j)).^3*W0^(-1/3)*A_int;

SigPE2(j)=10^(-12)*z(j).^2; 

l0=0.001;
Qm=35.05*z(j)/(k*l0^2);
q=0.74*Sig2Ry*Qm^(1/6);  % z > z_i
%q=1.22*Sig2Ry^(6/5);      % z < z_i
Theta0=1-z(j)/R0;
Lambda0=2*z(j)/(k*W0^2);
Theta=Theta0/(Theta0^2+Lambda0^2);
Lambda=Lambda0/(Theta0^2+Lambda0^2);
Rlt=-z(j)*(1+4*q*Lambda/3)/(1-Theta+2*q*Lambda);

Wlt2(j)=Wz2*(1+4*q*Lambda/3);

%%%% Weak/Yura's condition
rho0=(0.548*k^2*Cn2*z(j)).^(-3/5);
Wlt2_Y(j)=Wz2+8*(z(j)).^2/(k*rho0)^2;
SigTB2_weak=0.1337*lambda^2*z(j).^2/(W0^(1/3)*rho0^(5/3));
Wst2_Y(j)=Wz2+8*(z(j)).^2/(k*rho0)^2-SigTB2_weak;

z_km(j)=z(j)/1000;
end

figure(1) 
semilogy(z_km,SigPE2,z_km,SigTB2,z_km,Wlt2,'LineWidth',2)
%plot(z,Wlt2_Y,z,Wlt2,'LineWidth',2)
%plot(z,SigR)
set(gca,'FontSize',14)
xlabel('Distance (m)','FontSize',14)
ylabel('Variance (m^2)','FontSize',14)
%xlim([-3 205])
%ylim([1e-7 1e4])