clear all
close all
clc

W0=5e-2;
lambda=800e-9;
k=2*pi/lambda;
zR=pi*W0^2/lambda;
L0=1;
C0=2*pi;
kappa0=C0/L0;

eta_eff=.5;
eta_cd=.63;

aR=.30;    % Effects n_B xxx Be careful xxx 

Cn2=1.28e-14;         %  NIGHT 1.28e-14  DAY 2.06e-14
nbar_B5cm=4.8e-12;     %  NIGHT 4.8e-12   DAY 4.8e-7
nbar_B=(aR/0.05)^2*nbar_B5cm;
nbar_ex=0.001;
nbar=eta_eff*nbar_B+nbar_ex;
l0=0.001;
z_i=(Cn2*k^2*l0^(5/3))^(-1);

z=10e3;
mu=10;
beta=.98;

N=linspace(1e6,1e10,1e5);

% Transmisivity : Begin
h=30;
alpha0=5e-6;
eta_atm=exp(-alpha0*exp(-h/6600)*z);

R0=inf; 
Wz2=W0^2*((1-z/R0).^2+(z/zR).^2);
Sig2_Ry=1.23*Cn2*k^(7/6)*(z)^(11/6);

q=1.22*Sig2_Ry^(6/5);          % z < z_i
Theta0=1-z/R0;
Lambda0=2*z/(k*W0^2);
Theta=Theta0/(Theta0^2+Lambda0^2);
Lambda=Lambda0/(Theta0^2+Lambda0^2);
Rlt=-z*(1+4*q*Lambda/3)/(1-Theta+2*q*Lambda);

Wlt2=Wz2*(1+4*q*Lambda/3);

eta_lt=1-exp(-2*aR^2/Wlt2);
eta_ltfar=2*aR^2/Wlt2;
eta=eta_lt*eta_eff*eta_cd*eta_atm;
% Transmisivity : End

for j=1:length(N)

% PE
n=.9*N(j);
m=N(j)-n;
d=2^5; 
p_ec=0.9;
eps_s=1e-10;
eps_h=1e-10;
eps_cor=1e-10;
w=6.34;
%Delta_aep=4*sqrt(log2(18/(p_ec^2*eps_s^4)))*log2(2*sqrt(d)+1); % OLD
Delta_aep=4*sqrt(log2(18/(p_ec^2*eps_s^4)))*log2(sqrt(d)+2);
Theta_rate=log2(p_ec*(1-eps_s^2/3))+2*log2(sqrt(2)*eps_h);
% PE

eta_wc=eta-2*w*sqrt( (2*eta^2+eta*(2*nbar+1)/(mu-1)^2) /m);
nbar_wc=nbar+w*(2*nbar+1)/sqrt(2*m);

[R_peHOM R_peHET]=R_asympHom(beta,mu,eta_wc,nbar_wc);       
K_HOM(j)=(n/N(j))*p_ec*(R_peHOM-Delta_aep/sqrt(n)+Theta_rate/n);
K_HET(j)=(n/N(j))*p_ec*(R_peHET-Delta_aep/sqrt(n)+Theta_rate/n);

end

figure(1)
loglog(N,K_HOM,'LineWidth',2,'Color',[0.71 0.45 0.51])
set(gca,'FontSize',14)
xlabel('Block size','FontSize',14)
ylabel('Rates (bits/use)','FontSize',14)
xlim([1e7 1.1e10])
%ylim([1e-7 1e-4])

