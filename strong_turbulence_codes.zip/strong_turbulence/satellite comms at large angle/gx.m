function out=gx(x)
if x==1
    out=0;
else
out=((x+1)/2).*log2((x+1)/2)-((x-1)/2).*log2((x-1)/2);
end
