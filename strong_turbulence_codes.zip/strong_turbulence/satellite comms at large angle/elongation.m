function [z]=elongation(h0,n0,H,R,theta)
 
    Z=theta;
    Z_a=asin(sin(Z)/n0);    
    
    %TABLE V [Vasylyev PRA 99, 053830 (2019)]
    n0=n0;             H0=h0;
    n1=1+14660e-8;     H1=5e3;
    n2=1+11142e-8;     H2=7e3;
    n3=1+6141e-8;      H3=11e3;
    n4=1+3268e-8;      H4=15e3;
    n5=1+1485e-8;      H5=20e3;
    n6=1+235e-8;       H6=32e3;
    n7=1+34e-8;        H7=47e3;
    n8=1+ 21e-8;       H8=51e3;
    n9=1+1e-8;         H9=71e3;
    n10=1+0.1e-8;      H10=84.8e3; 
    
    [Phi1 Phi2 Phi3 Phi4 Phi5 Phi6 Phi7 Phi8 Phi9 Phi10 Thet10]=Phis(h0,H,R,Z,Z_a);
    
    L1=sqrt((R+H0)^2+(R+H1)^2-2*(R+H0)*(R+H1)*cos(Phi1));
    L2=sqrt((R+H1)^2+(R+H2)^2-2*(R+H1)*(R+H2)*cos(Phi2));
    L3=sqrt((R+H2)^2+(R+H3)^2-2*(R+H2)*(R+H3)*cos(Phi3));
    L4=sqrt((R+H3)^2+(R+H4)^2-2*(R+H3)*(R+H4)*cos(Phi4));
    L5=sqrt((R+H4)^2+(R+H5)^2-2*(R+H4)*(R+H5)*cos(Phi5));
    L6=sqrt((R+H5)^2+(R+H6)^2-2*(R+H5)*(R+H6)*cos(Phi6));
    L7=sqrt((R+H6)^2+(R+H7)^2-2*(R+H6)*(R+H7)*cos(Phi7));
    L8=sqrt((R+H7)^2+(R+H8)^2-2*(R+H7)*(R+H8)*cos(Phi8));
    L9=sqrt((R+H8)^2+(R+H9)^2-2*(R+H8)*(R+H9)*cos(Phi9));
    L10=sqrt((R+H9)^2+(R+H10)^2-2*(R+H9)*(R+H10)*cos(Phi10));
    L11=sqrt((R+H10)^2+(R+H)^2-2*(R+H10)*(R+H)*cos(Thet10));    
    
    %z=sqrt(H^2+2*H*R+(R*cos(Z))^2)-R*cos(Z);
    %eps_r=(L1+L2+L3+L4+L5+L6+L7+L8+L9+L10+L11)/L;
    z=L1+L2+L3+L4+L5+L6+L7+L8+L9+L10+L11;
end