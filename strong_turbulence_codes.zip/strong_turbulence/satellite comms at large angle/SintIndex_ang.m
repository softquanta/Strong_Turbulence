clear all
close all
clc

lambda=800e-9;
k=2*pi/lambda;
R_E=6370e3;

h0=30;
H=200e3;

nu=21;  % NIGHT 21   DAY 57
A=1.7e-14;  % NIGHT 1.7e-14   DAY 2.75e-14

funcCn2=@(x) ((5.94e-53)*(nu/27)^2*x.^10.*exp(-x/1000)+(2.7e-16)*exp(-x/1500)+A*exp(-x/100)).*(x-h0).^(5/6);
Cn2=integral(funcCn2,h0,H);

theta=linspace(1.045,1.48353,1e3);

for j=1:length(theta)

Sig2_Ry=2.25*k^(7/6)*(sec(theta(j)))^(11/6)*Cn2;
Sig2_Ryh(j)=exp(0.49*Sig2_Ry/(1+1.11*Sig2_Ry^(6/5))^(7/6)+0.51*Sig2_Ry/(1+0.69*Sig2_Ry^(6/5))^(5/6))-1;

theta_deg(j)=180*theta(j)/pi;    

end

plot(theta_deg,Sig2_Ryh,'LineWidth',2)%,'Color',[1 0.5 0])
set(gca,'FontSize',14)
xlabel('Zenith angle, \theta (deg)','FontSize',14)
ylabel('\sigma_I^2','FontSize',14)
xlim([59 86])
ylim([.38 1.28])

