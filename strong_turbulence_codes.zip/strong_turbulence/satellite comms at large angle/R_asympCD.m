function [R_peHOM R_peHET]=R_asympCD(beta,mu,eta,nbar)

a=mu;
b=eta*(mu-1)+2*nbar+1;
c=sqrt(eta*(mu^2-1));

I_ABhom=(1/2)*log2(1+eta*(mu-1)/(2*nbar+1));
I_ABhet=log2(1+eta*(mu-1)/(2*nbar+2));

nu_p=(sqrt((a+b)^2-4*c^2)+(b-a))/2;
nu_n=(sqrt((a+b)^2-4*c^2)-(b-a))/2;

nu_chom=sqrt(mu^2-mu*eta*(mu^2-1)/b);
chi_EBhom=gx(nu_p)+gx(nu_n)-gx(nu_chom);

nu_chet=mu-eta*(mu^2-1)/(b+1);
chi_EBhet=gx(nu_p)+gx(nu_n)-gx(nu_chet);

R_peHOM=beta*I_ABhom-chi_EBhom;
R_peHET=beta*I_ABhet-chi_EBhet;

end