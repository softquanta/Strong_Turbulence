clear all
close all
clc

lambda=800e-9;
k=2*pi/lambda;
R_E=6370e3;
h0=30;

theta=1%4*pi/9;

nu=57;  % NIGHT 21   DAY 57
A=2.75e-14;  % NIGHT 1.7e-14   DAY 2.75e-14

h=linspace(8e3,200e3,1e3);

for j=1:length(h)
% h=h0+z*cos(theta); % is an approximate for theta< 1 rad and h < h_max

C=cos(theta);
z=sqrt((R_E+h(j))^2+(R_E+h0)^2*(C^2-1))-(R_E+h0)*C;

funcCn2=@(x) ((5.94e-53)*(nu/27)^2*x.^10.*exp(-x/1000)+(2.7e-16)*exp(-x/1500)+A*exp(-x/100)).*(x-h0).^(5/6);
Cn2=integral(funcCn2,h0,h(j));
Sig2_Ry=2.25*k^(7/6)*(sec(theta))^(11/6)*Cn2;
Sig2_Ryh(j)=exp(0.49*Sig2_Ry/(1+1.11*Sig2_Ry^(6/5))^(7/6)+0.51*Sig2_Ry/(1+0.69*Sig2_Ry^(6/5))^(5/6))-1;

z_km(j)=z/1000;
h_km(j)=h(j)/1000;
end

plot(h_km,Sig2_Ryh,'LineWidth',2)%,'Color',[1 0.5 0])
set(gca,'FontSize',14)
xlabel('Altitude, h (km)','FontSize',14)
ylabel('\sigma^2','FontSize',14)
xlim([0 205])
ylim([0.2 1.4])


