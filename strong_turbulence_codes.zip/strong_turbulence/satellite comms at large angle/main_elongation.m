clear all
close all
clc

W0=20e-2;       
aR=40e-2;       
lambda=800e-9;
k=2*pi/lambda;
zR=pi*W0^2/lambda;

eta_cd=0.63;

theta=4*pi/9;

nu=21;  % NIGHT 21   DAY 57
A=1.7e-14;  % NIGHT 1.7e-14   DAY 2.75e-14
 
eta_eff=.5;
R=6370e3;

h0=0; n0=1+27340e-8; % n0 varies with distnace.
alpha0=5e-6;
R0=inf; 
L0=1;
C0=2*pi;
kappa0=C0/L0;
l0=0.001;

h=linspace(100e3,600e3,1e3);   % h>>20 km

for j=1:length(h)

[z]=elongation(h0,n0,h(j),R,theta);

funcCn2=@(x) ((5.94e-53)*(nu/27)^2*x.^10.*exp(-x/1000)+(2.7e-16)*exp(-x/1500)+A*exp(-x/100)).*(x-h0).^(5/6);
Cn2=integral(funcCn2,h0,h(j));
Sig2_Ry=2.25*k^(7/6)*(sec(theta))^(11/6)*Cn2;
 
Wz2=W0^2*((1-z/R0).^2+(z/zR).^2);

% Effective radius of curvature : Begin
Qm=35.05*z/(k*l0^2);
q=0.74*Sig2_Ry*Qm^(1/6);        % z > z_i
%q=1.22*Sig2_Ryh^(6/5);         % z < z_i
Theta0=1-z/R0;
Lambda0=2*z/(k*W0^2);
Theta=Theta0/(Theta0^2+Lambda0^2);
Lambda=Lambda0/(Theta0^2+Lambda0^2);  
% Effective radius of curvature : End

% Effective long-term spot radius : Begin
Wlt2=Wz2*(1+4*q*Lambda/3);
% Effective long-term spot radius : End

% Effective long-term transmisivity : Begin
eta_lt=1-exp(-2*aR^2/Wlt2);   % LOG-NORMAL MODEL

eta_atm=exp(-alpha0*exp(-h(j)/6600)*z);

eta(j)=eta_lt*eta_eff*eta_atm;
% Effective long-term transmisivity : End

h_km(j)=h(j)/1000;
end

figure(1)
plot(h_km,eta,'LineWidth',2)
set(gca,'FontSize',14)
xlabel('Altitude, h (km)','FontSize',14)
ylabel('optical loss, \eta','FontSize',14)
xlim([95 605])
%ylim([1e-9 10])