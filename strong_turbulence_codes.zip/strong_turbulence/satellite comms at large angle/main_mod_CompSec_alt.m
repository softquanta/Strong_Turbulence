clear all
close all
clc

W0=20e-2;       
aR=70e-2;
eta_eff=0.5; eta_cd=0.63;
lambda=800e-9;
k=2*pi/lambda;
zR=pi*W0^2/lambda;
L0=1;
C0=2*pi;
kappa0=C0/L0;
l0=0.001;
R0=inf; 

theta=4*pi/9;
R=6371e3;

nu=21;      % NIGHT 21   DAY 57
A=1.7e-14;  % NIGHT 1.7e-14   DAY 2.75e-14
nbar_B5cm=4.75e-12;    %  NIGHT 4.8e-12   DAY 4.8e-7
nbar_B=(aR/0.05)^2*nbar_B5cm;
nbar_ex=0.001;
nbar=eta_eff*nbar_B+nbar_ex;
 
N=5e12;
% PE
d=2^5; 
p_ec=0.9;
eps_s=1e-10;
eps_h=1e-10;
eps_cor=1e-10;
w=6.34;
%Delta_aep=4*sqrt(log2(18/(p_ec^2*eps_s^4)))*log2(2*sqrt(d)+1); % OLD
Delta_aep=4*sqrt(log2(18/(p_ec^2*eps_s^4)))*log2(sqrt(d)+2);
Theta_rate=log2(p_ec*(1-eps_s^2/3))+2*log2(sqrt(2)*eps_h);
% PE
mu=10;
beta=.98;
n=.9*N;
m=N-n;

h=linspace(85e3,600e3,1e3);

for j=1:length(h)
    
h0=30; n0=1+27340e-8; % n0 varies with distnace.
alpha0=5e-6;

[z]=elongation(h0,n0,h(j),R,theta);

eta_atm=exp(-alpha0*exp(-h(j)/6600)*z);
Wz2=W0^2*((1-z/R0).^2+(z/zR).^2);

funcCn2=@(x) ((5.94e-53)*(nu/27)^2*x.^10.*exp(-x/1000)+(2.7e-16)*exp(-x/1500)+A*exp(-x/100)).*(x-h0).^(5/6);
Cn2=integral(funcCn2,h0,h(j));
Sig2_Ry=2.25*k^(7/6)*(sec(theta))^(11/6)*Cn2;
Sig2_Ryh=exp(0.49*Sig2_Ry/(1+1.11*Sig2_Ry^(6/5))^(7/6)+0.51*Sig2_Ry/(1+0.69*Sig2_Ry^(6/5))^(5/6))-1;
%z_i=(Cn2*k^2*l0^(5/3))^(-1)
%q=1.22*Sig2_Ryh^(6/5);         % z < z_i
Qm=35.05*z/(k*l0^2);
q=0.74*Sig2_Ryh*Qm^(1/6);        % z > z_i
Theta0=1-z/R0;
Lambda0=2*z/(k*W0^2);
Theta=Theta0/(Theta0^2+Lambda0^2);
Lambda=Lambda0/(Theta0^2+Lambda0^2);
Wlt2=Wz2*(1+4*q*Lambda/3);

eta_lt=1-exp(-2*aR^2/Wlt2); % LOG-NORMAL MODEL
eta=eta_lt*eta_eff*eta_cd*eta_atm;

eta_wc=eta-2*w*sqrt( (2*eta^2+eta*(2*nbar+1)/(mu-1)^2) /m);
nbar_wc=nbar+w*(2*nbar+1)/sqrt(2*m);
 
[R_peHOM R_peHET]=R_asympCD(beta,mu,eta_wc,nbar_wc);       
K_HOM(j)=(n/N)*p_ec*(R_peHOM-Delta_aep/sqrt(n)+Theta_rate/n);
K_HET(j)=(n/N)*p_ec*(R_peHET-Delta_aep/sqrt(n)+Theta_rate/n);

h_km(j)=h(j)/1000;
end

figure(1)
semilogy(h_km,K_HOM,'LineWidth',2)
set(gca,'FontSize',14)
xlabel('Altitude (km)','FontSize',14)
ylabel('Rates (bits/use)','FontSize',14)
%xlim([82 275])
%ylim([1e-6 5e-2])

