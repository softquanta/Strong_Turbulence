function [Phi1 Phi2 Phi3 Phi4 Phi5 Phi6 Phi7 Phi8 Phi9 Phi10 Thet10]=Phis(h0,H,R,Z,Z_a)

    %TABLE V [Vasylyev PRA 99, 053830 (2019)]
    n0=1+27340e-8;     H0=h0;
    n1=1+14660e-8;     H1=5e3;
    n2=1+11142e-8;     H2=7e3;
    n3=1+6141e-8;      H3=11e3;
    n4=1+3268e-8;      H4=15e3;
    n5=1+1485e-8;      H5=20e3;
    n6=1+235e-8;       H6=32e3;
    n7=1+34e-8;        H7=47e3;
    n8=1+ 21e-8;       H8=51e3;
    n9=1+1e-8;         H9=71e3;
    n10=1+0.1e-8;      H10=84.8e3;

    C0=R/(R+H0);
    C1=R/(R+H1);
    C2=R/(R+H2);
    C3=R/(R+H3);
    C4=R/(R+H4);
    C5=R/(R+H5);
    C6=R/(R+H6);
    C7=R/(R+H7);
    C8=R/(R+H8);
    C9=R/(R+H9);
    C10=R/(R+H10);
    CH=R/(R+H);
        
    bet_0=acos(C0*sin(Z)/n0);
    bet_1=acos(C1*sin(Z)/n1);
    bet_2=acos(C2*sin(Z)/n2);
    bet_3=acos(C3*sin(Z)/n3);
    bet_4=acos(C4*sin(Z)/n4);
    bet_5=acos(C5*sin(Z)/n5);
    bet_6=acos(C6*sin(Z)/n6);
    bet_7=acos(C7*sin(Z)/n7);
    bet_8=acos(C8*sin(Z)/n8);
    bet_9=acos(C9*sin(Z)/n9);
    bet_10=acos(C10*sin(Z)/n10);   
    %bet_10=acos(CH*sin(Z));  % Gives the same result.

        
    alph_1=acos(n1*cos(bet_1)/n0);
    alph_2=acos(n2*cos(bet_2)/n1);
    alph_3=acos(n3*cos(bet_3)/n2);
    alph_4=acos(n4*cos(bet_4)/n3);
    alph_5=acos(n5*cos(bet_5)/n4);
    alph_6=acos(n6*cos(bet_6)/n5);
    alph_7=acos(n7*cos(bet_7)/n6);
    alph_8=acos(n8*cos(bet_8)/n7);
    alph_9=acos(n9*cos(bet_9)/n8);
    alph_10=acos(n10*cos(bet_10)/n9);

    r1=2*(n0-n1)/(tan(bet_0)+tan(bet_1));
    r2=2*(n1-n2)/(tan(bet_1)+tan(bet_2));
    r3=2*(n2-n3)/(tan(bet_2)+tan(bet_3));
    r4=2*(n3-n4)/(tan(bet_3)+tan(bet_4));
    r5=2*(n4-n5)/(tan(bet_4)+tan(bet_5));
    r6=2*(n5-n6)/(tan(bet_5)+tan(bet_6));
    r7=2*(n6-n7)/(tan(bet_6)+tan(bet_7));
    r8=2*(n7-n8)/(tan(bet_7)+tan(bet_8));
    r9=2*(n8-n9)/(tan(bet_8)+tan(bet_9));
    r10=2*(n9-n10)/(tan(bet_9)+tan(bet_10));
        
    chi_1=r1-(alph_1-bet_1);
    chi_2=r2-(alph_2-bet_2);
    chi_3=r3-(alph_3-bet_3);
    chi_4=r4-(alph_4-bet_4);
    chi_5=r5-(alph_5-bet_5);
    chi_6=r6-(alph_6-bet_6);
    chi_7=r7-(alph_7-bet_7);
    chi_8=r8-(alph_8-bet_8);
    chi_9=r9-(alph_9-bet_9);
    chi_10=r10-(alph_10-bet_10);
      
    alph_01=pi/2-Z_a;
    psi_2=asin(C2*sin(Z_a-bet_1+alph_01)/C1);
    
    alph_02=alph_2-alph_01+bet_1+chi_2+psi_2-Z_a;
    psi_3=asin(C3*sin(Z_a-bet_2+alph_02)/C2);
    
    alph_03=alph_3-alph_02+bet_2+chi_3+psi_3-Z_a;
    psi_4=asin(C4*sin(Z_a-bet_3+alph_03)/C3);
    
    alph_04=alph_4-alph_03+bet_3+chi_4+psi_4-Z_a;
    psi_5=asin(C5*sin(Z_a-bet_4+alph_04)/C4);
    
    alph_05=alph_5-alph_04+bet_4+chi_5+psi_5-Z_a;    
    psi_6=asin(C6*sin(Z_a-bet_5+alph_05)/C5);
    
    alph_06=alph_6-alph_05+bet_5+chi_6+psi_6-Z_a;
    psi_7=asin(C7*sin(Z_a-bet_6+alph_06)/C6);
    
    alph_07=alph_7-alph_06+bet_6+chi_7+psi_7-Z_a;
    psi_8=asin(C8*sin(Z_a-bet_7+alph_07)/C7);    
    
    alph_08=alph_8-alph_07+bet_7+chi_8+psi_8-Z_a;
    psi_9=asin(C9*sin(Z_a-bet_8+alph_08)/C8);
    
    alph_09=alph_9-alph_08+bet_8+chi_9+psi_9-Z_a;
    psi_10=asin(C10*sin(Z_a-bet_9+alph_09)/C9);
    
    alph_010=alph_10-alph_09+bet_9+chi_10+psi_10-Z_a;
        
    Phi1=alph_1-alph_01+chi_1;
    Phi2=alph_2-alph_02+chi_2;
    Phi3=alph_3-alph_03+chi_3;
    Phi4=alph_4-alph_04+chi_4;
    Phi5=alph_5-alph_05+chi_5;
    Phi6=alph_6-alph_06+chi_6;
    Phi7=alph_7-alph_07+chi_7;
    Phi8=alph_8-alph_08+chi_8;
    Phi9=alph_9-alph_09+chi_9;
    Phi10=alph_10-alph_010+chi_10;
    
    delt_10=atan((cos(alph_10)-cos(alph_10+chi_10))/(sin(alph_10+chi_10)-C10*sin(alph_010)/C9));
    psi=asin(CH*sin(r10-delt_10+psi_10)/C10);
    Thet10=r10-delt_10+psi_10-psi;
end